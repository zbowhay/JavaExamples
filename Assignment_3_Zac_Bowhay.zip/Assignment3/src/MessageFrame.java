//MessageFrame class, responsible for creating a frame
import java.awt.*;
import javax.swing.*;

public class MessageFrame extends JFrame{
	public MessageFrame(){
		setTitle("Message in a Bottle");
		setSize(450,450);
		setDefaultCloseOperation(EXIT_ON_CLOSE);
	}
}
