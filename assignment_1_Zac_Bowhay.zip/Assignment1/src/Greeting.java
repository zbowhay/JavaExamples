// Problem 1, Not Hello World
public class Greeting {
	public static void main(String[] args){
		System.out.println("Howdy Earth!");
	}
}
